package com.green.jpa_study;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaStudyApplicationTests {

	@Test
	void contextLoads() {
	}

}
